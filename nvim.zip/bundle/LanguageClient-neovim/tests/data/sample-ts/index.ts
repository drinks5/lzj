[1, 2].length
