#!/bin/sh
cd rplugin/node/nvim_typescript && npm install && npm run build
