**Warning:  I will close the issue without the minimal vimrc and the reproduce ways.**

# Problems summary


## Expected


## Environment Information

 * terminal:
 * vim/nvim version:



## Provide a minimal vim rc with less than 50 lines (Required!)

```vim
" Your minimal init.vim
set runtimepath+=~/path/to/nvim-typescript
```


## The reproduce ways from neovim starting

 1. foo
 2. bar
 3. baz

## Example project repo?

Most common errors are related to a project not being set up correctly.
Please provid a minimal project example to reduce back-and-forth time.
This makes debugging MUCH easier


## Screen shot (if possible)


