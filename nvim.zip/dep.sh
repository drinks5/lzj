# 执行方式如 arch
# env install='pacman -S --noconfirm' ./local
$install neovim git curl wget openssh python zsh gcc nodejs npm tmux ripgrep autojump openssh python-pip
